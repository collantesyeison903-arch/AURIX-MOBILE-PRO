AURIX MOBILE PRO - Proyecto Android

Qué es:
Aplicación Android que envuelve AURIX Mobile PRO en una WebView local. La interfaz ya no depende de abrir archivos HTML desde content://downloads, evitando el problema de Android que abría copias antiguas v5.

Incluye:
- XAU/USD y datos de Twelve Data.
- M5, M15, M30 y H1.
- Solo velas cerradas para la señal.
- Confluencia mínima 3/4 antes de mostrar una entrada operativa.
- BUY / SELL / ESPERAR.
- Entrada, SL, TP1 y TP2 cuando hay confirmación.
- Gestión de riesgo y alertas del navegador dentro de la WebView.
- Sin ejecución automática de órdenes en MT5.

IMPORTANTE:
- La API Key se guarda en localStorage de la WebView del dispositivo. No compartas tu clave.
- La app usa internet para consultar Twelve Data.
- La versión incluida es una base funcional para compilar como APK; este entorno no dispone del toolchain completo de Android para entregar una APK compilada.

Compilación:
1. Abrir la carpeta del proyecto en Android Studio.
2. Esperar la sincronización de Gradle.
3. Build > Build APK(s).
4. Instalar la APK generada en el teléfono.

Android recomienda Kotlin para proyectos nuevos y Android Studio para crear/compilar apps.
