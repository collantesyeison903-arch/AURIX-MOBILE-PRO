

VERSION 8: lectura de la vela M15 actual mediante /quote de Twelve Data, análisis con velas cerradas, y contador automático de 20 operaciones virtuales (TP1/SL). La app no ejecuta órdenes reales.
